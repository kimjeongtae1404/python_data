﻿import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        rows = []
        for row in reader:
            rows.append(row)
        return rows

def save_csv(path, rows, columns):
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)

TOPIC = 1
KEY = 'lot_id'
COLUMNS = ['lot_id', 'production_date', 'product_name', 'material_lot', 'equipment_name', 'customer_name', 'shipped_qty']

class Manager:
    def __init__(self):
        self.raw_rows = []
        self.valid_rows = []
        self.error_rows = []

    def load_data(self):
        self.raw_rows = []
        for path in sorted((ROOT / "data").glob("*.csv")):
            for number, row in enumerate(read_csv(path), 2):
                row["source_file"] = path.name
                row["source_line"] = number
                self.raw_rows.append(row)

    def validate_data(self):
        # TODO: 원본을 검사하여 정상/오류 리스트를 채우세요.
        # int 또는 float 변환 실패는 try/except ValueError로 처리할 수 있습니다.
        raise NotImplementedError("오류 검사 기능을 구현하세요")

    def summarize_data(self):
        # TODO: 딕셔너리로 그룹별 합계를 계산하세요.
        raise NotImplementedError("집계 기능을 구현하세요")

    def save_results(self):
        # TODO: results 폴더 생성 후 save_csv 함수를 활용하세요.
        raise NotImplementedError("결과 저장 기능을 구현하세요")

if __name__ == "__main__":
    manager = Manager()
    manager.load_data()
    print("읽은 행 수:", len(manager.raw_rows))
    print("첫 번째 행:", manager.raw_rows[0] if manager.raw_rows else "데이터 없음")
    print("읽기 기능만 완성된 시작 코드입니다. 나머지 기능을 구현하세요.")
    # 구현 후 아래 호출을 활성화하세요.
    # manager.validate_data()
    # manager.summarize_data()
    # manager.save_results()
