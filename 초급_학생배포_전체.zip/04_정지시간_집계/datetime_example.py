﻿from datetime import datetime
start = datetime.strptime("2026-09-01 23:40:00", "%Y-%m-%d %H:%M:%S")
end = datetime.strptime("2026-09-02 00:30:00", "%Y-%m-%d %H:%M:%S")
minutes = (end-start).total_seconds()/60
print("정지 시간:", minutes, "분")  # 50분
